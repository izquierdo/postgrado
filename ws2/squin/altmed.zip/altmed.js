//
//  Copyright 2009 Olaf Hartig
//
//  This file is part of the alternative medicine Linked Data mash-up.
//
//  The alternative medicine Linked Data mash-up is free software:
//  you can redistribute it and/or modify it under the terms of the
//  GNU General Public License as published by the Free Software
//  Foundation, either version 3 of the License, or (at your option)
//  any later version.
//
//  The alternative medicine Linked Data mash-up is distributed in the
//  hope that it will be useful, but WITHOUT ANY WARRANTY; without even
//  the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
//  PURPOSE.  See the GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with the alternative medicine Linked Data mash-up.  If not,
//  see <http://www.gnu.org/licenses/>.
//

function submitted ()
{
	var drugname = document.getElementById("drugname").value;

	if ( drugname == "" ) {
		return;
	}

	document.getElementById("submitBtn").style.display = "none";
	document.getElementById("submitBtn").disabled = true;
	document.getElementById("drugname").disabled = true;
	document.getElementById("changeBtn").style.display = "inline";
	document.getElementById("board").innerHTML = "searching for drugs named '" + drugname + "' <span style='text-decoration:blink'>...</span>";

	var drugLookupQuery = "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\n" +
	                      "PREFIX drugbank: <http://www4.wiwiss.fu-berlin.de/drugbank/resource/drugbank/>\n" +
	                      "SELECT ?uri ?label WHERE {\n" +
	                      "  ?uri a drugbank:drugs .\n" +
	                      "  ?uri rdfs:label ?label .\n" +
	                      "  FILTER( regex(STR(?label),'" + drugname + "','i') )\n" +
	                      "}\n";
	                      "ORDER BY ?uri";
	var url = "callback.php?source=drugbank&query=" + encodeURIComponent(drugLookupQuery);
	new Ajax.Request( url, {
		method: 'get',
		onSuccess: drugLookupQueryCallback,
		onFailure: function(response) {
			alert( "AJAX request failed for drugLookupQuery: " + response.responseText );
  		}
	} );
}

function change ()
{
	document.getElementById("submitBtn").style.display = "inline";
	document.getElementById("submitBtn").disabled = false;
	document.getElementById("drugname").disabled = false;
	document.getElementById("changeBtn").style.display = "none";
	document.getElementById("boardheader").innerHTML = "";
	document.getElementById("board").innerHTML = "";
}

function drugLookupQueryCallback ( transport )
{
	var bindings = transport.responseText.evalJSON().results.bindings;
	if ( bindings.length == 1 )
	{
		selectedDrugURI( bindings[0].uri.value, bindings[0].label.value );
	}
	else if ( bindings.length == 0 )
	{
		document.getElementById("board").innerHTML = "Sorry, no such drug found.";
	}
	else
	{
		var prevURI = "";
		var html = "<div>Multiple drugs found for your query - please select one:<ul>";
		for ( var i = 0 ; i < bindings.length ; i++ )
		{
			if ( bindings[i].uri.value != prevURI ) // consider each thing only once
			{
				prevURI = bindings[i].uri.value;
				html += "<li><a href='javascript:selectedDrugURI(\"" + bindings[i].uri.value + "\",\"" + bindings[i].label.value + "\");'>'" + bindings[i].label.value + "' (with URI " + bindings[i].uri.value + ")</a></li>";
			}
		}
		html += "</ul></div>";
		document.getElementById("board").innerHTML = html;
	}
}

function selectedDrugURI( uri, label )
{
	document.getElementById("boardheader").innerHTML = "<h1>Natural alternatives for drug '<a href='" + uri + "'>" + label + "</a>'</h1>";
	document.getElementById("board").innerHTML = "Querying the Web for alternative medicines now <span style='text-decoration:blink'>...</span>";

	var altDrugQuery = "PREFIX rdf:  <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n" +
	                   "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\n" +
	                   "PREFIX owl:  <http://www.w3.org/2002/07/owl#>\n" +
	                   "PREFIX drugbank: <http://www4.wiwiss.fu-berlin.de/drugbank/resource/drugbank/>\n" +
	                   "PREFIX tcm:      <http://purl.org/net/tcm/tcm.lifescience.ntu.edu.tw/>\n" +
	                   "SELECT DISTINCT ?disease ?diseaseLabel ?altMedicine ?altMedicineLabel WHERE {\n" +
	                   "<" + uri + "> drugbank:possibleDiseaseTarget ?disease.\n" +
	                   "?disease owl:sameAs ?sameDisease.\n" +
	                   "?sameDisease rdf:type tcm:Disease.\n" +
	                   "?altMedicine tcm:treatment ?sameDisease.\n" +
	                   "?altMedicine rdf:type tcm:Medicine.\n" +
	                   "?disease rdfs:label ?diseaseLabel.\n" +
	                   "?altMedicine rdfs:label ?altMedicineLabel.\n" +
	                   "}\n" +
	                   "ORDER BY ?sameDisease";
	var url = "callback.php?source=web&query=" + encodeURIComponent(altDrugQuery);
	new Ajax.Request( url, {
		method: 'get',
		onSuccess: altDrugQueryCallback,
		onFailure: function(response) {
			alert( "AJAX request failed for altDrugQuery: " + response.responseText );
  		}
	} );	
}

function altDrugQueryCallback ( transport )
{
	var bindings = transport.responseText.evalJSON().results.bindings;
	var html = "";
	if ( bindings.length > 0 )
	{
		var timestamp = new Date().getTime();
		var curDisease = "";
		for ( var i = 0 ; i < bindings.length ; i++ )
		{
			if ( curDisease != bindings[i].disease.value )
			{
				curDisease = bindings[i].disease.value;
				html += "<h2>... to treat '<a href='" + bindings[i].disease.value + "'>" + bindings[i].diseaseLabel.value + "</a>'</h2>";
			}
			html += "<div>'<a href='" + bindings[i].altMedicine.value + "'>" + bindings[i].altMedicineLabel.value + "</a>'";
			html += "<span id='EffectLink_" + timestamp + "_" + i + "'> (";
			html += "<a href='javascript:showSideEffects(\"" + timestamp + "_" + i + "\",\"" + bindings[i].altMedicine.value + "\");'>show side effects</a>";
			html += ")</span>";
			html += "<div id='EffectBoard_" + timestamp + "_" + i + "' style='margin-left:40px; padding-bottom:10px'></div>";
			html += "</div>";
		}
	}
	else
	{
		html += "nothing found";
	}
	document.getElementById("board").innerHTML = html;
}

function showSideEffects ( id, uri )
{
	linkElmt = document.getElementById("EffectLink_"+id);
	boardElmt = document.getElementById("EffectBoard_"+id);
	if ( linkElmt == null || boardElmt == null ) {
		return;
	}

	linkElmt.innerHTML = "";
	boardElmt.innerHTML = "querying for side effects <span style='text-decoration:blink'>...</span>";

	var sideEffectQuery = "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\n" +
	                      "PREFIX owl:  <http://www.w3.org/2002/07/owl#>\n" +
	                      "PREFIX tcm:      <http://purl.org/net/tcm/tcm.lifescience.ntu.edu.tw/>\n" +
	                      "PREFIX dailymed: <http://www4.wiwiss.fu-berlin.de/dailymed/resource/dailymed/>\n" +
	                      "PREFIX sider:    <http://www4.wiwiss.fu-berlin.de/sider/resource/sider/>\n" +
	                      "SELECT DISTINCT ?effect ?effectname WHERE {\n" +
	                      "        <" + uri + "> tcm:ingredient ?ingredient .\n" +
	                      "        ?dailymedIngredient owl:sameAs ?ingredient .\n" +
	                      "        ?drug dailymed:activeIngredient ?dailymedIngredient .\n" +
	                      "        ?drug owl:sameAs ?sider_drug .\n" +
	                      "        ?sider_drug a sider:drugs .\n" +
	                      "        ?sider_drug sider:sideEffect ?effect .\n" +
	                      "        ?effect rdfs:label ?effectname .\n" +
	                      "}\n" +
	                      "ORDER BY ?effectname";


	var url = "callback.php?source=web&query=" + encodeURIComponent(sideEffectQuery);
	new Ajax.Request( url, {
		method: 'get',
		onSuccess: function(transport) {
			sideEffectQueryCallback(transport,id);
		},
		onFailure: function(response) {
			alert( "AJAX request failed for sideEffectQuery: " + response.responseText );
  		}
	} );	
}

function sideEffectQueryCallback ( transport, id )
{
	boardElmt = document.getElementById("EffectBoard_"+id);
	if ( boardElmt == null ) {
		return;
	}

	var bindings = transport.responseText.evalJSON().results.bindings;
	var html = "";
	if ( bindings.length > 0 )
	{
		html += "Possible side effects: ";
		for ( var i = 0 ; i < bindings.length ; i++ )
		{
			html += "'<a href='" + bindings[i].effect.value + "'>" + bindings[i].effectname.value + "</a>' ";
		}
	}
	else
	{
		html += "no side effects found";
	}
	boardElmt.innerHTML = html;
}