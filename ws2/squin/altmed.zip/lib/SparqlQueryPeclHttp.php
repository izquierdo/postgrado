<?php
/*
  Copyright 2009 DBIS Research Group at Humboldt-Universität zu Berlin

  This file is part of Researchers Map.

  Researchers Map is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Researchers Map is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with Researchers Map.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
 * SQUIN SPARQL Query PHP library - implementation class based on pecl_http
 * 
 * This file extends the generic class with the neccessary low-level operations
 * 
 * @author Hannes Muehleisen <hannes@living-site.net>
 * @version 0.1
 * @package SparqlQuery
 * @link http://pecl.php.net/package/pecl_http official pecl_http website
 * 
 */

/** 
 * The generic Query class
 */
require_once "SparqlQueryGeneric.php";
 
 /**
 * SparqlQueryPeclHttp
 * This class extends the generic class with the neccessary low-level operations
 * based on the pecl_http classes
 * @see SparqlQueryGeneric
 * @package SparqlQuery
 * 
 */
class SparqlQueryPeclHttp extends SparqlQueryGeneric {
	/**
	 * Calls the SQUIN Server via a HTTP GET request using pecl_http
	 * @return string the server answer
	 * @throws SparqlQueryException
	 */
	public function callServer() {
		// throw an exception if the HttpRequest from pecl_http is not available
		if (!class_exists('HttpRequest')) throw new SparqlQueryException("php pecl_http extension is not installed!",-1);
		// create the new request
		$r = new HttpRequest($this->server_url, HttpRequest::METH_GET);
		
		// set some parameters
		$params = $this->query_params;
		$params['query'] = stripslashes($this->query);
		if (!$this->useCache) $params['ignoreQueryCache'] = "true";
		
		// set some http header options
		$options = array(
			'timeout' => $this->timeout,
			'useragent' => 'DBIS SPARQL Client 0.1 ' . phpversion());

		$r->setOptions($options);
		$r->addQueryData($params);
		
		// executes the query
	    $r->send();
	    
	    if ($r->getResponseCode() == 200) {
	        $result = $r->getResponseBody();
	        if (empty($result)) throw new SparqlQueryException("Result empty, query failed", "-1");
	        return $result;
	    }
	    else {
	    	throw new SparqlQueryException(strip_tags($r->getResponseBody()),$r->getResponseCode());
	    }
	}
}
