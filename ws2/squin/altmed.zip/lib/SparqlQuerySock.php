<?php
/*
  Copyright 2008, 2009 DBIS Research Group at Humboldt-Universität zu Berlin

  This file is part of SQUIN.

  SQUIN is free software: you can redistribute it and/or modify it under the
  terms of the GNU General Public License as published by the Free Software
  Foundation, either version 3 of the License, or (at your option) any later
  version.

  SQUIN is distributed in the hope that it will be useful, but WITHOUT ANY
  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
  FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
  details.

  You should have received a copy of the GNU General Public License
  along with SQUIN.  If not, see <http://www.gnu.org/licenses/>.
*/
/**
 * SQUIN SPARQL Query PHP library - implementation class based on php sockets
 * 
 * This file contains a class which extends the generic class with the neccessary low-level operations
 * 
 * @author Hannes Muehleisen <hannes@living-site.net>
 * @version 0.1
 * @package SparqlQuery
 * 
 */
 
/** 
 * The generic Query class
 */
require_once "SparqlQueryGeneric.php";

 /**
 * SparqlQuerySock
 * This class extends the generic class with the neccessary low-level operations
 * @see SparqlQueryGeneric
 * @package SparqlQuery
 * 
 */
class SparqlQuerySock extends SparqlQueryGeneric {
	/**
	 * Calls the SQUIN Server via a HTTP GET request using custom functions
	 * @return string the server answer
	 * @throws SparqlQueryException
	 */
	public function callServer() {
		$res_raw = $this->do_request($this->query_params);
		$result = $this->parse_result($res_raw);
		if (is_array($result) && isset ($result['error_code'])) {
			throw new SparqlQueryException($result['error_msg'], $result['error_code']);
		}
		return $result;
	}

	/**
	 * Checks if the result is empty
	 * @param string raw result
	 * @return string checked result
	 */
	private function parse_result($res_raw) {
		if (empty($res_raw)) {
			throw new SparqlQueryException("Query failed", "-1");
		}

		return $res_raw;
	}

	/**
	 * Executes a request to the SQUIN server via HTTP GET
	 * @param array $params HTTP GET parameters for the query
	 */
	private function do_request($params) {
		$result = "";
		// build request string from params
		$request_string = $this->server_url . "?" . $this->create_request_string($params);
		// set some http request options
		$context = array (
			'http' => array (
				'method' => 'GET',
				'user-agent: DBIS SPARQL Client 0.1 ' . phpversion() . "\r\n",
				'timeout' => $this->timeout
			)
		);
		
		$contextid = stream_context_create($context);
		$sock = @fopen($request_string, 'r', false, $contextid);
		if ($sock) {
			stream_set_timeout($sock, $this->timeout);
			$result = '';
			while (!feof($sock)) $result .= fgets($sock, 4096);
			
			$info = stream_get_meta_data($sock);				
			fclose($sock);
			if ($info['timed_out']) throw new SparqlQueryException("Query timed out");

		}
		else { // something went wrong
			if (isset($http_response_header) && !empty($http_response_header[0])) {
				throw new SparqlQueryException("Query failed: " . @$http_response_header[0]);
			}
			else {
				throw new SparqlQueryException("Query timeout or other error.");
			}
		}
		return $result;
	}
	
	/**
	 * Creates the request string from a key-value array
	 * example: $q->create_request_string(array('somekey'=>'someval','otherkey'=>'otherval'))
	 * becomes somekey=someval&otherkey=otherval
	 * @param array $params key-value pairs
	 * @return string GET string
	 */
	private function create_request_string($params) {
		if (!$this->useCache) {
			$params['ignoreQueryCache'] = "true";
		}
		
		$params['query'] = stripslashes($this->query);
		
		$post_params = array ();
		foreach ($params as $key => & $val) {
			if (is_array($val))
				$val = implode(',', $val);
			$post_params[] = $key . '=' . urlencode($val);
		}
		return implode('&', $post_params);
	}		
}