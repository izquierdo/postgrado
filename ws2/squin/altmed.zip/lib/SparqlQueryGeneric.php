<?php
/*
  Copyright 2009 DBIS Research Group at Humboldt-Universität zu Berlin

  This file is part of SQUIN.

  SQUIN is free software: you can redistribute it and/or modify it under the
  terms of the GNU General Public License as published by the Free Software
  Foundation, either version 3 of the License, or (at your option) any later
  version.

  SQUIN is distributed in the hope that it will be useful, but WITHOUT ANY
  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
  FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
  details.

  You should have received a copy of the GNU General Public License
  along with SQUIN.  If not, see <http://www.gnu.org/licenses/>.
*/


/**
 * SQUIN SPARQL Query PHP library - generic code
 * 
 * This file provides basic classes for querying
 * a SQUIN SPARQL Server.
 * 
 * See example.php in this directory for an example.
 * 
 * @author Hannes Muehleisen <hannes@living-site.net>
 * @version 0.1
 * @package SparqlQuery
 * 
 */
 
 /**
 * SparqlQueryGeneric
 * 
 * IMPORTANT: this class cannot be instantiated on its own.
 * create an instance of one of the derived classes instead!
 * 
 * This class provides basic methods for querying
 * a SQUIN SPARQL Server but has to be extended with further methods
 * 
 * See example.php in this directory for an example.
 * 
 * @package SparqlQuery
 * @see SparqlQueryGeneric.php
 * 
 */
abstract class SparqlQueryGeneric {
	/**
	 * SQUIN Server URL to connect to
	 * @var string
	 */
	protected $server_url;
	
	/**
	 * SPARQL Query to execute
	 * @var string
	 */
	protected $query;
	
	/**
	 * Should SQUIN use its built-in cache?
	 * @see setUseCache()
	 * @var boolean
	 */
	protected $useCache = true;
	
	/**
	 * Maximum wait time for an answer from SQUIN
	 * has to be smaller than the maximum allowed runtime for php scripts
	 * @see setTimeout()
	 * @var integer
	 */
	protected $timeout;
	
	/**
	 * Array for additional GET parameters within the SQUIN query
	 * user should normally not add own parameters, but rather use 
	 * the built-in functions.
	 * @var array
	 */
	protected $query_params = array();
	
	/**
	 * Class constructor
	 * takes a server url and a SPARQL query as parameters.
	 * Important: the query is not executed until one of getXmlResult(), 
	 * getJsonResult() or getArrayResult() is called.
	 * 
	 * @param string $a_server_url HTTP URL to SQUIN server
	 * @param string $a_query SPARQL query
	 * @param array $params HTTP GET Parameters for SQUIN query
	 * @return SparqlQuery* instance of child chlass
	 */
	public function __construct($a_server_url, $a_query, $params = array()) {
		$this->server_url = $a_server_url;
		$this->query = $a_query;	
		$this->query_params = $params;
		$this->timeout = $this->getSysTimeout();
		return $this;
	}
	
	/**
	 * Tells SQUIN to use its internal triple cache, true speeds up answers greatly
	 * @param boolean $use true if cache should be used, also the default value
	 */
	public function setUseCache($use) {
		$this->useCache = $use;
	}
	
	/**
	 * Returns the query results as a JSON representation
	 * @link http://json.org/ JSON Homepage
	 * @link http://www.w3.org/TR/rdf-sparql-json-res/ W3C Format Definitin
	 */
	public function getJsonResult() {
		$this->query_params['output'] = 'json';
		return $this->callServer();
	}
	
	/**
	 * Returns the query results as a XML representation
	 * @link http://www.w3.org/TR/rdf-sparql-XMLres/ W3C Format Definition
	 */
	public function getXmlResult() {
		return $this->callServer();
	}
	
	/** 
	 * Returns the query results as a PHP array from the JSON format
	 * @see getJsonResult()
	 */
	public function getArrayResult() {
		return json_decode($this->getJsonResult(),true);
	}
	
	/** 
	 * Abstract function to be implemented by the child classes
	 * Known Implementations: SparqlQueryPeclHttp and SparqlQuerySock
	 * @throws SparqlQueryException
	 */
	abstract function callServer();

	/* GETTERS AND SETTERS */
	/** 
	 * Get the SQUIN server url
	 * @return string
	 */
	public function getServerUrl() {
		return $this->server_url;
	}
	
	/**
	 * Set the used SQUIN server url
	 * @param string $a_server_url the new url
	 */
	public function setServerUrl($a_server_url) {
		$this->server_url = $a_server_url;
	}
	
	/**
	 * Get the SPARQL Query
	 * @return string SPARQL query
	 */
	public function getQuery() {
		return $this->query;
	}
	
	/**
	 * Set the SPARQL query
	 * @param string $a_query the SPARQL query as String
	 */
	public function setQuery($a_query) {
		$this->query = $a_query;
	}
	
	/**
	 * Get the current timeout for the SQUIN HTTP GET request
	 * @return integer the current timeout
	 */
	public function getTimeout() {
		return $this->timeout;
	}
	
	/**
	 * Sets the timeout to be used for the SQUIN HTTP GET request
	 * Checks if the given timeout is bigger than the maxmimum script execution time
	 * throws exception if that is the case, because the class is not able to commit to
	 * the users request for the timeout.
	 * @param integer $timeout
	 * @throws SparqlQueryException 
	 */
	public function setTimeout($timeout) {
		$this->timeout = $timeout;
		if ($this->getSysTimeout() < $timeout) throw new SparqlQueryException("timeout ($timeout) is bigger than max_execution_time php config value (".$this->getSysTimeout().")",-1);
	}
	
	/**
	 * Fetches the current PHP maximum script runtime
	 * @return integer maximum php execution time
	 */
	protected function getSysTimeout() {
		return ini_get('max_execution_time');	
	}
	
	/**
	 * Get the current GET parameters for the SQUIN HTTP request
	 * @return array array of key-value pairs, may be empty
	 */
	public function getQueryParams() {
		return $this->query_params;
	}
	
	/**
	 * Return a single GET parameter for the SQUIN HTTP request
	 * returns the value if the value is present, otherwise false
	 * @return string|boolean
	 */
	public function getQueryParam($key) {
		if (!isset($this->query_params[$key])) return false;
		return $this->query_params[$key];
	}
	
	/**
	 * Set multiple GET parameters for the SQUIN HTTP request
	 * example: $q->setQueryParams(array('somekey'=>'somevalue','otherkey'=>'othervalue'));
	 * becomes in the query: ...&somekey=somevalue&otherkey=othervalue
	 * @param array $options array of key-value pairs
	 */
	public function setQueryParams($options) {
		$this->params = $options;
	}
	
	/**
	 * Set single GET parameter for the SQUIN HTTP request
	 * example: $q->setQueryParam('somekey','somevalue')
	 * becomes in the query: ...&somekey=somevalue
	 * @param string $key
	 * @param string $value
	 */
	public function setQueryParam($key,$value) {
		$this->params[$key] = $value;
	}

}

/**
 * Exception class for Sparql Queries
 * @package SparqlQuery
 */
class SparqlQueryException extends Exception {}