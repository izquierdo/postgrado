<?php
/*
  Copyright 2009 Olaf Hartig

  This file is part of the alternative medicine Linked Data mash-up.

  The alternative medicine Linked Data mash-up is free software:
  you can redistribute it and/or modify it under the terms of the
  GNU General Public License as published by the Free Software
  Foundation, either version 3 of the License, or (at your option)
  any later version.

  The alternative medicine Linked Data mash-up is distributed in the
  hope that it will be useful, but WITHOUT ANY WARRANTY; without even
  the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
  PURPOSE.  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with the alternative medicine Linked Data mash-up.  If not,
  see <http://www.gnu.org/licenses/>.
*/

// error handling
error_reporting(E_ALL);
ini_set('display_errors', '1');
set_time_limit(600); // 10 minutes, should be enough
require("lib/SparqlQuerySock.php");

if ( $_REQUEST['source'] == "drugbank" ) {
	define('SPARQL_SERVICE','http://www4.wiwiss.fu-berlin.de/drugbank/sparql');
}
else if ( $_REQUEST['source'] == "web" ) {
	define('SPARQL_SERVICE','http://localhost:8080/SQUIN/query');
}

$q = new SparqlQuerySock(SPARQL_SERVICE, $_REQUEST['query']);
if (isset($_REQUEST['nocache'])) {
	$q->setUseCache(false);
}
try {
	// execute query and convert results to JSON
	$res = $q->getJsonResult();
	print $res;
	
}
catch (Exception $e) {
	header("HTTP/1.1 404 Not Found");
	print $e->getMessage();
}


?>
