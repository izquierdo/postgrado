export LD_LIBRARY_PATH=/home/julio/yoli/tesis/jcprof/
